﻿using EasyHook;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using PlmHook;
using System.Threading;

namespace PLMInject
{
    public class Main : IEntryPoint
    {
        private readonly HookHandler Interface;
        private LocalHook SetForegroundWindow;
        private LocalHook Show_Window;
        private LocalHook IsZoomed;
        private LocalHook SetWindowTextW;
        private IntPtr HWND = IntPtr.Zero;

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
        private delegate bool SetForegroundWindow_delegate(IntPtr hwnd);

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
        private delegate bool IsZoomed_delegate(IntPtr hwnd);

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
        private delegate bool ShowWindow_delegate(IntPtr hwnd, int Cmd);

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
        private delegate bool SetWindowTextW_delegate(IntPtr hwnd, IntPtr Cmd);

        public Main(RemoteHooking.IContext InContext, String InChannelName)
        {
            Interface = RemoteHooking.IpcConnectClient<HookHandler>(InChannelName);
        }

        public void Run(RemoteHooking.IContext InContext, String InChannelName)
        {
            try
            {
                SetForegroundWindow =
                   LocalHook.Create(
                       LocalHook.GetProcAddress("swt-win32-3721.dll",
                           "_Java_org_eclipse_swt_internal_win32_OS_SetForegroundWindow@12"),
                       new SetForegroundWindow_delegate(SetForegroundWindow_Hooked), this);
                Show_Window = LocalHook.Create(LocalHook.GetProcAddress("user32.dll", "ShowWindow"),
                    new ShowWindow_delegate(ShowWindow_Hooked), this);
                IsZoomed = LocalHook.Create(
                    LocalHook.GetProcAddress("swt-win32-3721.dll",
                        "_Java_org_eclipse_swt_internal_win32_OS_IsZoomed@12"), new IsZoomed_delegate(IsZoomed_Hooked),
                    this);
                SetWindowTextW = LocalHook.Create(LocalHook.GetProcAddress("user32.dll", "SetWindowTextW"),
                    new SetWindowTextW_delegate(SetWindowTextW_Hooked), this);

                SetForegroundWindow.ThreadACL.SetExclusiveACL(new Int32[] { 0 });

                Interface.IsInstalled(RemoteHooking.GetCurrentThreadId());
                RemoteHooking.WakeUpProcess();
            }
            catch (Exception ExtInfo)
            {
                Interface.ReportException("状态:Hook失败");
                return;
            }

            try
            {
                while (true)
                {
                    if (!Interface.check()) break;
                    Thread.Sleep(500);
                    ;
                }
            }
            finally
            {
                SetForegroundWindow.Dispose();
                Show_Window.Dispose();
                IsZoomed.Dispose();
                SetWindowTextW.Dispose();
                LocalHook.Release();
            }
        }

        private bool SetWindowTextW_Hooked(IntPtr hwnd, IntPtr Cmd)
        {
            Main This = (Main)HookRuntimeInfo.Callback;
            if (Marshal.PtrToStringAuto(Cmd) == "请确认")
            {
               Interface.GetWindowsHandle(hwnd);
            }
           Show_Window.ThreadACL.SetExclusiveACL(new Int32[] { 0 });
           IsZoomed.ThreadACL.SetExclusiveACL(new Int32[] { 0 });
           SetWindowTextW.ThreadACL.SetExclusiveACL(new Int32[] { 0 });
            return LocalHook.GetProcDelegate<SetWindowTextW_delegate>("user32.dll", "SetWindowTextW")(hwnd, Cmd);
        }

        private bool IsZoomed_Hooked(IntPtr hwnd)
        {
            Main This = (Main)HookRuntimeInfo.Callback;
            if (This.HWND == hwnd &&HWND != IntPtr.Zero)
            {
                return false;
            }
            else
            {
                var Ret = LocalHook.GetProcDelegate<IsZoomed_delegate>("swt-win32-3721.dll", "_Java_org_eclipse_swt_internal_win32_OS_IsZoomed@12");
                return Ret(hwnd);
            }
        }

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hwnd, int cmd);

        private bool ShowWindow_Hooked(IntPtr hwnd, int Cmd)
        {
            if (Cmd == 3) Cmd = 8;
            return ShowWindow(hwnd, Cmd);
        }

        private bool SetForegroundWindow_Hooked(IntPtr hwnd)
        {
            Main This = (Main)HookRuntimeInfo.Callback;
            HWND = hwnd;
           Show_Window.ThreadACL.SetInclusiveACL(new Int32[] { 0 });
           IsZoomed.ThreadACL.SetInclusiveACL(new Int32[] { 0 });
           SetWindowTextW.ThreadACL.SetInclusiveACL(new Int32[] { 0 });
            return true;
        }
    }
}
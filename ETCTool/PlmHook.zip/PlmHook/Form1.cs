﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Runtime.Remoting;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyHook;
using Timer = System.Threading.Timer;

namespace PlmHook
{
    public partial class Form1 : Form
    {
        public static Label Status2;
        public static CheckBox Check2;

        public Form1()
        {
            InitializeComponent();
        }

        public static CancellationTokenSource Cancel = new CancellationTokenSource();
        private Dictionary<int, string> PIDandChannel = new Dictionary<int, string>();
        private System.Timers.Timer time = new System.Timers.Timer(10000);

        private void Start_Click(object sender, EventArgs e)
        {
            if (Start.Text == @"开始")
            {
                Cancel = new CancellationTokenSource();
                time = new System.Timers.Timer(10000);
                time.AutoReset = true;
                time.Elapsed += delegate
                {
                    var PidList = new List<int>();
                    foreach (var PID in new ManagementObjectSearcher(
                        new SelectQuery(
                            $"Select Name,ProcessId from Win32_Process Where (Name = 'DigiWin PLM.exe')")).Get())
                    {
                        int Pid = int.Parse(PID["ProcessId"].ToString());
                        PidList.Add(Pid);
                        if (!PIDandChannel.ContainsKey(Pid))
                        {
                            try
                            {
                                string ChannelName = null;
                                RemoteHooking.IpcCreateServer<HookHandler>(ref ChannelName,
                                    WellKnownObjectMode.SingleCall);
                                RemoteHooking.Inject(
                                    Pid,
                                    InjectionOptions.Default,
                                    $"PLMInject.dll",
                                    $"PLMInject.dll",
                                    ChannelName);
                                PIDandChannel.Add(Pid, ChannelName);
                            }
                            catch (Exception exception)
                            {
                                Invoke(new Action(() => { Status.Text = $@"状态:{exception}"; }));
                            }
                        }
                    }

                    var DelList = new List<int>();

                    foreach (var VARIABLE in PIDandChannel)
                    {
                        if (!PidList.Contains(VARIABLE.Key))
                        {
                            DelList.Add(VARIABLE.Key);
                        }
                    }

                    foreach (var VARIABLE in DelList)
                    {
                        PIDandChannel.Remove(VARIABLE);
                    }

                    if (PIDandChannel.Count == 0)
                    {
                        Invoke(new Action(() =>
                        {
                            Status.Text = $@"状态:未找到PLM程序";
                        }));
                    }
                };
                time.Disposed += delegate { PIDandChannel = new Dictionary<int, string>(); };
                time.Start();
                Start.Text = @"关闭";
                Status.Text = $@"状态:运行";
            }
            else
            {
                Cancel.Cancel();
                time.Stop();
                time.Close();
                Status.Text = $@"状态:";
                Start.Text = @"开始";
            }
        }
    }
}
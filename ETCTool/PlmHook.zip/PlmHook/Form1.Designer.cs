﻿namespace PlmHook
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            Start = new System.Windows.Forms.Button();
            Check = new System.Windows.Forms.CheckBox();
            Status = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // Start
            // 
            Start.Location = new System.Drawing.Point(13, 13);
            Start.Name = "Start";
            Start.Size = new System.Drawing.Size(75, 23);
            Start.TabIndex = 0;
            Start.Text = "开始";
            Start.UseVisualStyleBackColor = true;
            Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // Check
            // 
           Check.AutoSize = true;
           Check.Location = new System.Drawing.Point(94, 17);
           Check.Name = "Check";
           Check.Size = new System.Drawing.Size(72, 16);
           Check.TabIndex = 1;
           Check.Text = "自动确定";
           Check.UseVisualStyleBackColor = true;
            // 
            // Status
            // 
           Status.AutoSize = true;
           Status.Location = new System.Drawing.Point(12, 41);
           Status.Name = "Status";
           Status.Size = new System.Drawing.Size(35, 12);
           Status.TabIndex = 2;
           Status.Text = "状态:";
            // 
            // Form1
            // 
           AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
           AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
           ClientSize = new System.Drawing.Size(184, 62);
           Controls.Add(Status);
           Controls.Add(Check);
           Controls.Add(Start);
           MaximumSize = new System.Drawing.Size(200, 100);
           MinimumSize = new System.Drawing.Size(200, 100);
           Name = "Form1";
           ShowIcon = false;
           Text = "PLM";
           ResumeLayout(false);
           PerformLayout();

        }

        #endregion

        public static System.Windows.Forms.Button Start;
        public static System.Windows.Forms.CheckBox Check;
        public static System.Windows.Forms.Label Status;
    }
}


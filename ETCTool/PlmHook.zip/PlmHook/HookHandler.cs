﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlmHook
{
    public class HookHandler : MarshalByRefObject
    {
        public void ReportException(string v)
        {
            Form1.Status.Invoke(new Action(() => { Form1.Status.Text = v; }));
        }

        public void IsInstalled(int v)
        {
            Form1.Status.Invoke(new Action(() => { Form1.Status.Text = $@"状态:hook地址{v.ToString()}"; }));
        }

        [DllImport("User32.dll ")]
        public static extern IntPtr FindWindowEx(System.IntPtr parent, System.IntPtr childe, string strclass,
            string strname);

        [DllImport("user32.dll")]
        private static extern int SendMessageA(IntPtr hwnd, int wMsg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr hwnd, uint wMsg);

        [DllImport("user32.dll")]
        public static extern int GetWindowTextW(IntPtr hWnd, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder lpString,
            int nMaxCount);

        public void GetWindowsHandle(IntPtr hwnd)
        {
            Form1.Status.Invoke(new Action(() =>
            {
                if (Form1.Check.Checked)
                {
                    ThreadPool.QueueUserWorkItem((object state) =>
                    {
                        Thread.Sleep(1000);
                        var GetText = new StringBuilder(256);
                        GetWindowTextW(hwnd, GetText, 256);
                        for (int i = 0; i < 10; i++)
                        {
                            IntPtr childHwnd = FindWindowEx(hwnd, IntPtr.Zero, "SWT_Window0", "");
                            if (childHwnd != IntPtr.Zero)
                            {
                                for (int j = 0; j < 10; j++)
                                {
                                    var Button = FindWindowEx(childHwnd, IntPtr.Zero, "Button", "确定");
                                    if (Button == IntPtr.Zero)
                                    {
                                        childHwnd = GetWindow(childHwnd, 2);
                                    }
                                    else
                                    {
                                        int ret = SendMessageA(Button, 0xF5, IntPtr.Zero, IntPtr.Zero);
                                        do
                                        {
                                            ret = SendMessageA(Button, 0xF5, IntPtr.Zero, IntPtr.Zero);
                                        } while (ret != 0);

                                        break;
                                    }
                                }
                            }

                            Thread.Sleep(1000);
                        }
                    });
                }
            }));
        }

        public bool check()
        {
            bool Run = false;
            Form1.Status.Invoke(new Action(() =>
            {
                Run = !Form1.Cancel.IsCancellationRequested;
            }));
            return Run;
        }
    }
}
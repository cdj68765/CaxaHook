using System;
using System.Collections.Generic;
using System.Text;

namespace WPFFolderBrowser.Interop
{
    // wpffb used
    internal enum NativeDialogShowState
    {
        PreShow,
        Showing,
        Closing, 
        Closed
    }
}
